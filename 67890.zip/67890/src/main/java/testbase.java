import java.io.*;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class testbase{

	long numbervalue;
	String xpathvalue;
	String methodname;
	FileInputStream fis=null;
	Boolean Flag=true;
	
	Boolean runtest(WebDriver driver){
	try {
	fis = new FileInputStream(new File("src//main//resources//Test_steps.xlsx"));
	XSSFWorkbook wb=new XSSFWorkbook(fis);   
	XSSFSheet sheet=wb.getSheetAt(0);  
	int rows = sheet.getLastRowNum();
	for (int i=1;i<=rows;i+=1)
	{
		String textvalue=null;
		String name=null;
		methodname=sheet.getRow(i).getCell(1).getStringCellValue();
		System.out.println("Step "+ i+": ");
		
		if(sheet.getRow(i).getCell(3)!=null) {
		switch(sheet.getRow(i).getCell(3).getCellType())
		{
		case STRING: textvalue=sheet.getRow(i).getCell(3).toString();break;
		case NUMERIC: numbervalue=(long) sheet.getRow(i).getCell(3).getNumericCellValue();break;
		case BOOLEAN:break;
		case _NONE:break;
		case BLANK: break;
		case FORMULA: break;
		case ERROR: break;
		default: break;
//		textvalue=sheet.getRow(i).getCell(3).toString();
		}
		}
		
		if(sheet.getRow(i).getCell(4)!=null)
			name=sheet.getRow(i).getCell(4).toString();
		
		if(sheet.getRow(i).getCell(2)!=null) {
		xpathvalue=sheet.getRow(i).getCell(2).getStringCellValue().trim();}
		switch(methodname)
		{
		case "openURL": openURL(driver, textvalue);
						break;
		case "click": clickElement(driver, xpathvalue, name);
					  break;
		case "entertext": entertext(driver, xpathvalue,textvalue,name);
						  break;
		case "wait": Thread.sleep((numbervalue)*1000);
					 System.out.println("Wait for "+numbervalue+" seconds");break;
		case "close": quitBrowser(driver);System.out.println("Browser closed.");break;
		case "maximizewindow": maximizewindow(driver);break;
		default: System.out.println("Error! Incorrect keyword used.");Flag=false;break;
		}
	}
	wb.close();
	}
	catch(Exception e) {
		e.printStackTrace();}
	return Flag;
	}
	
	void openURL(WebDriver driver, String textvalue)
	{
		driver.get(textvalue);
		System.out.println("URL opened: "+textvalue);
	}
	
	void clickElement(WebDriver driver, String xpathvalue, String name)
	{
		try {
		driver.findElement(By.xpath(xpathvalue)).click();
		System.out.println("Element Clicked: "+name);
		}
		catch(Exception e)
		{System.out.println("Unable to click element. ");
		e.printStackTrace();
		Flag=false;
		}
	}
	
	void entertext(WebDriver driver, String xpathvalue, String value, String name)
	{
		try {
		driver.findElement(By.xpath(xpathvalue)).sendKeys(value);
		System.out.println("Text Entered in "+name+": "+value);
		}catch(Exception e)
		{
			System.out.println("Text not entered. ");
			e.printStackTrace();
			Flag=false;
		}
	}
	
	void quitBrowser(WebDriver driver)
	{
		driver.quit();
	}
	
	void maximizewindow(WebDriver driver)
	{
		driver.manage().window().maximize();
		System.out.println("Window Maximised");
	}
}
